<P > <h2><B>Début d'indexation:  </B>  <?php echo " ", date ("h:i:s"); ?></h2></P>

<?php

include 'resources/fonctions.inc.php';

//Augmentation du temps d'exécution de ce script
set_time_limit (500);
$path= "data";
// Appel à la fonction d'indexation d'un repertoire 
indexerRepertoire($path);

?>

<P><h2><B>Fin d'indexation :   </B> <?php echo " ", date ("h:i:s"); ?></h2></P>
